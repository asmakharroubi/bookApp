export const ADD_TASK = "ADD_TASK";
export const CHANGE_DONE = "CHANGE_DONE";
export const EDIT_TASK = "EDIT_TASK";